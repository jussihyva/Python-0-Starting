# Training Piscine Python for datascience - 0 Starting

## Exercise 09

Create your first package in python the way you want, it will appear in the list of
installed packages when you type the command "pip list" and display its characteristics
when you type "pip show -v ft_package"

## References

[Packaging Python Projects](https://packaging.python.org/en/latest/tutorials/packaging-projects)
