def count_in_list(strings: list, string: str) -> int:
    num_of_occures = strings.count(string)
    return num_of_occures
